package com.example.assignment_core3

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView


class AdaptMedals (var medals:List<Medallist>):RecyclerView.Adapter<AdaptMedals.viewHolder_medals>(){
    class viewHolder_medals(itemView: View) : RecyclerView.ViewHolder(itemView){

        //values are created for the three main fields, along with it's respective IDs
        val title:TextView=itemView.findViewById(R.id.titleMedallist)
        val ioc:TextView=itemView.findViewById(R.id.IOCmedallist)
        val count:TextView=itemView.findViewById(R.id.medalCnt)
    }

    //this is to set up the widgets as created in the layout resources and call the layout inflater on a fragment
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): viewHolder_medals {
        val itemLayout=LayoutInflater.from(parent.context).inflate(R.layout.layoutmedallist,parent,false)
        return viewHolder_medals(itemLayout)
    }
    @SuppressLint("ClickableViewAccessibility")

    //this function is used to get hold of how the data gets fill in the holders when we want it to be displayed
    override fun onBindViewHolder(holder: viewHolder_medals, position: Int) {

        //values are created for the list of medal positions and the total number of medals is calculated
        val listofMedalsData:Medallist=medals[position]
        val numofMedals=medals[position].getSum()

        //when scrolling, we can get the view holder used that went off the emulator's screen and the old data is replaced to the new data
        holder.count.text=numofMedals.toString()
        holder.ioc.text=medals[position].iocCode
        holder.title.text=medals[position].name

        //value is created to get the data of the top ten medallists
        val toptenData=retrievetenData()
        if (medals[position].iocCode in toptenData){
            holder.itemView.findViewById<View>(R.id.layoutMedallist).setBackgroundResource(R.color.teal_200)


        }
        else{
            holder.itemView.findViewById<View>(R.id.layoutMedallist).setBackgroundResource(R.color.white)
        }

        //the medallists data are saved and stored to the shared preferences - to keep track of the last data clicked
        fun dataStored(){
            val act=holder.itemView.context as AppCompatActivity
            val shr_Pref=act.getSharedPreferences("Shared_Preferences",Context.MODE_PRIVATE)
            val edit=shr_Pref.edit()
            edit.apply{
                putString("title",listofMedalsData.name)
                putString("ioc",listofMedalsData.iocCode)
                putInt("gold",listofMedalsData.goldMed)
                putInt("silver",listofMedalsData.silverMed)
                putInt("bronze",listofMedalsData.bronzeMed)

                apply()

            }

        }
        holder.itemView.findViewById<TextView>(R.id.titleMedallist).setOnTouchListener { v, event ->
            val act = holder.itemView.context as AppCompatActivity
            val bottshefrag = BottomSheetFrag.newInstance()
            val doing = event.action
            when (doing) {
                // this is to make a bottom sheet (data about the medallist) to appear
                MotionEvent.ACTION_DOWN -> {
                    dataStored()
                    act.supportFragmentManager
                        .beginTransaction()
                        .add(R.id.idConstraint, bottshefrag, "countryMedals")
                        .commit()
                }

                // this is to make a bottom sheet (data about the medallist) to disappear when onClicked
                MotionEvent.ACTION_UP -> {
                    val fragment = act.supportFragmentManager.findFragmentByTag("countryMedals")
                    if(fragment != null){
                        act.supportFragmentManager
                            .beginTransaction()
                            .remove(fragment)
                            .commit()
                    }
                }
                else -> {
                }
            }
            true
        }
    }

    //this function is used to get the data of the top ten countries
    private fun retrievetenData(): MutableList<String> {
        val toptenMeds= mutableListOf<String>()
        val listMeds= mutableListOf<TotalMedallist>()

        //this is to get the total number of medals of each country
        val count=medals.size -1
        for(i in 0..count){
            val ioc=medals[i].iocCode
            val totalmedals=medals[i].getSum()
            listMeds.add(TotalMedallist(ioc,totalmedals))
        }

        //this is used to sort the data list in a descending order (num of medals of countries from high to low)
        listMeds.sortByDescending { it.totalMedCnt}
        for(i in 0..9){
            toptenMeds.add(listMeds[i].iocCode)
        }
        return toptenMeds


    }

    //this function is used to return the size and the size should not be zero
    override fun getItemCount():Int{
        return medals.size
    }

}
