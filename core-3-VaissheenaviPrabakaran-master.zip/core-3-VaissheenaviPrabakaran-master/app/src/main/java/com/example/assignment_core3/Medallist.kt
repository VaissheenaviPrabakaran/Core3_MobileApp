package com.example.assignment_core3

//variables and data types are declared for the fields required in Medallist
data class Medallist (
    var name:String="",
    var iocCode:String="",
    var completeTimes:Int = 0,
    var goldMed:Int=0,
    var silverMed:Int=0,
    var bronzeMed:Int=0
)
{

    //this function is used to calculate the sum of the type/number of medals
    fun getSum() : Int{
        return this.goldMed + this.silverMed + this.bronzeMed
    }
}
