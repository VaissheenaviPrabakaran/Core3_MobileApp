package com.example.assignment_core3

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    //a variable for a list of medals is declared
    var medal_lists= mutableListOf<Medallist>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //a variable and an ID for recycler view is declared
        var recyc_vw=findViewById<RecyclerView>(R.id.recyclerVmedals)

        // this value is created for the bottom sheet fragment
        val btm_sht=findViewById<ConstraintLayout>(R.id.bottomSheetDialog)
        val appearance_btmSht=BottomSheetBehavior.from(btm_sht)

        appearance_btmSht.setHideable(true)
        appearance_btmSht.state=BottomSheetBehavior.STATE_HIDDEN

        //to is to enable the csv file that we have uploaded under the raw folder under res
        val input_File: InputStream = resources.openRawResource(R.raw.medallists)

        //this is to read the csv file
        val read=input_File.bufferedReader()
        read.readLine()

        var read_line=read.readLine()
        while(read_line!=null) {
            val columns: List<String> = read_line.split(",")
            val itemList = Medallist(
                columns[0],
                columns[1],
                columns[2].toInt(),
                columns[3].toInt(),
                columns[4].toInt(),
                columns[5].toInt()
            )
            medal_lists.add(itemList)
            read_line = read.readLine()
        }
        input_File.close()

        //this is to ensure the values has been passed to the adapter
        val adapt_medals=AdaptMedals(medal_lists)
        recyc_vw.adapter=adapt_medals
        recyc_vw.layoutManager=LinearLayoutManager(this)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val menu_infltr:MenuInflater=menuInflater
        menu_infltr.inflate(R.menu.savemenu,menu)
        return true
    }

    //this function is used to get the data that has been saved by the shared preferences
    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        //values are created for each fields respectively
        val shd_pref = getSharedPreferences("Shared_Preferences", Context.MODE_PRIVATE)
        val title_save = shd_pref.getString("title", null)
        val ioc_save = shd_pref.getString("ioc", null)
        val id=item.itemId
        if(id==R.id.ToSave){
            val intent= Intent(this,DetailsActivity::class.java).apply{
                putExtra("title",title_save)
                putExtra("ioc",ioc_save)
            }
            startActivity(intent)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}

