package com.example.assignment_core3

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class BottomSheetFrag : BottomSheetDialogFragment() {
    companion object{

        //this function is used to declare and return the bottom sheet fragment
        fun newInstance():BottomSheetFrag{
            return BottomSheetFrag()
        }
    }

    //this function creates and returns the view flow related to the fragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //the layout is inflated for this fragment
        val onView:View=inflater.inflate(R.layout.fragbottomsheet,container,false)
        return onView

    }

    //this function is normally called after the onCreateView function because it makes sure that the fragment is not null
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //values are created for the fields in the dialog bottom sheet
        val med_title=view.findViewById<TextView>(R.id.DBStitle)
        val med_gold=view.findViewById<TextView>(R.id.DBSgold)
        val med_silver=view.findViewById<TextView>(R.id.DBSsilver)
        val med_bronze=view.findViewById<TextView>(R.id.DBSbronze)
        val med_IOC=view.findViewById<TextView>(R.id.iocBS)

        //values are created and relevant datas are extracted for the fields
        val activities= activity as Context
        val Shd_Pref=activities.getSharedPreferences("Shared_Preferences",Context.MODE_PRIVATE)
        val appear_title=Shd_Pref.getString("title",null)

        //values are created for the medallists data and shared preferences is used to retrieve the data
        val dataG=Shd_Pref.getInt("gold",0)
        val dataS=Shd_Pref.getInt("silver",0)
        var dataB=Shd_Pref.getInt("bronze",0)
        var dataIOC=Shd_Pref.getString("ioc",null)

        //this is done for the information about medallists to be displayed on the bottom of the emulator's screen (when each country is clicked)
        med_title.text=appear_title
        med_gold.text=dataG.toString().plus(" gold medal(s)")
        med_silver.text=dataS.toString().plus(" silver medal(s)")
        med_bronze.text=dataB.toString().plus(" bronze medal(s)")
        med_IOC.text=dataIOC

    }

}