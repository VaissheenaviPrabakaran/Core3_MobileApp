package com.example.assignment_core3

//variable are declared and stored as string and integer
data class TotalMedallist(
    var iocCode: String = "",
    var totalMedCnt: Int = 0,

    ) {}