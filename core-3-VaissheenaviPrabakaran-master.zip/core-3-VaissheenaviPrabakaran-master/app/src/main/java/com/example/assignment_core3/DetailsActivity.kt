package com.example.assignment_core3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class DetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        //appropriate values are created and is used to display it on the second activity page
        val show_text=findViewById<TextView>(R.id.lastmedClick)
        val inp_title=intent.getStringExtra("title").toString()
        val inp_IOC=intent.getStringExtra("ioc").toString()
        val msg = "Last country clicked : $inp_title (${inp_IOC})"
        show_text.text = msg
    }
}